<?php
  $phenotypearray = array();
  
  $sqlphenotype = "SELECT PhenoID, Name FROM Phenotypes";
  
  $queryphenotype = mysql_query($sqlphenotype, $connect) or die(mysql_error());
  while($row = mysql_fetch_assoc($queryphenotype))
  {
    extract($row);
    $phenotypeid = $row["PhenoID"];
    $phenotypename = $row["Name"];
    $tmpphenotype = array($phenotypeid, $phenotypename);
    $phenotypearray[] = $tmpphenotype;
  }
?>