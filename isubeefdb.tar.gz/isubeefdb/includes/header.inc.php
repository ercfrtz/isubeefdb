<?php $currentPage = basename($_SERVER['SCRIPT_NAME']); ?>
<header class="navbar navbar-inverse navbar-static-top bs-docs-nav" role="banner">
	<div class="container">
		<div class="navbar-header">
    		<a class="navbar-brand" href="#">
    			ISUBEEFDB
			</a>
		</div>
		<nav class="collapse navbar-collapse bs-navbar-collapse" role="navigation">
			<ul class="nav navbar-nav">
  				<li <?php if($currentPage == 'index.php') {echo 'class="active"';} ?>><a href="index.php">Home</a></li>
  				<?php if(isset($_SESSION['authenticated'])){ ?>
  					<li <?php if($currentPage == 'search.php') {echo 'class="active"';} ?>><a href="search.php">Search</a></li>
  					<li <?php if($currentPage == 'data_in_database.php') {echo 'class="active"';} ?>><a href="data_in_database.php">Data In Database</a></li>
  					<li <?php if($currentPage == 'progeny_counts.php') {echo 'class="active"';} ?>><a href="progeny_counts.php">Progeny Counts</a></li>
  					<li <?php if($currentPage == 'pedigree_view.php') {echo 'class="active"';} ?>><a href="pedigree_view.php">Pedigree View</a></li>
  					<li <?php if($currentPage == 'single_animal_search.php') {echo 'class="active"';} ?>><a href="single_animal_search.php">Single Animal</a></li>
  					<li <?php if($currentPage == 'animal_search.php') {echo 'class="active"';} ?>><a href="animal_search.php">Animal Search</a></li>
  					<li><a href="logout.php">Logout</a></li>
  				<?php } ?>
			</ul>
		</nav>
	</div>
</header>