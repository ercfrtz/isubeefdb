<?php
  $upnarray = array();
  
  $sqlupn = "SELECT UPN FROM Pedigree WHERE Trial_ID > 1";
  
  $queryupn = mysql_query($sqlupn, $connect) or die(mysql_error());
  while($row = mysql_fetch_assoc($queryupn))
  {
    extract($row);
    $upnarray[] = $row["UPN"];
  }
?>