<?php
  $genearray = array();
  
  $sqlgene = "SELECT Gene_ID, GeneName FROM Gene";
  
  $querygene = mysql_query($sqlgene, $connect) or die(mysql_error());
  while($row = mysql_fetch_assoc($querygene))
  {
    extract($row);
    $geneid = $row["Gene_ID"];
    $genename = $row["GeneName"];
    $tempgene = array($geneid, $genename);
    $genearray[] = $tempgene;
  }
?>