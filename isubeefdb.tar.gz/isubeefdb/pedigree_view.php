<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

$animal="";
$parent1="";$parent2="";
$gp11="";$gp12="";$gp21="";$gp22="";
$gp111="";$gp112="";$gp121="";$gp122="";$gp211="";$gp212="";$gp221="";$gp222="";
$gp1111="";$gp1112="";$gp1121="";$gp1122="";$gp1211="";$gp1212="";$gp1221="";$gp1222="";
$gp2111="";$gp2112="";$gp2121="";$gp2122="";$gp2211="";$gp2212="";$gp2221="";$gp2222="";

if(array_key_exists('search', $_POST))
{
	$animal = $_POST["animalid"];
	$idtype = $_POST["idType"];
	
	if($idtype == "intid")
	{
		$sqlparents = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$animal."'";
		$queryparents = mysql_query($sqlparents, $connect) or die(mysql_error());
		while($row = mysql_fetch_assoc($queryparents))
		{extract($row);$parent1 = $row["SireID"];$parent2 = $row["DamID"];}
		if(!($parent1 == ""))
		{
			$sqlgp1 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$parent1."'";
			$querygp1 = mysql_query($sqlgp1, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp1))
			{extract($row);$gp11 = $row["SireID"];$gp12 = $row["DamID"];}
		}
		if(!($parent2 == ""))
		{
			$sqlgp2 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$parent2."'";
			$querygp2 = mysql_query($sqlgp2, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp2))
			{extract($row);$gp21 = $row["SireID"];$gp22 = $row["DamID"];}
		}
		if(!($gp11 == ""))
		{
			$sqlgp3 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp11."'";
			$querygp3 = mysql_query($sqlgp3, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp3))
			{extract($row);$gp111 = $row["SireID"];$gp112 = $row["DamID"];}
		}
		if(!($gp12 == ""))
		{
			$sqlgp4 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp12."'";
			$querygp4 = mysql_query($sqlgp4, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp4))
			{extract($row);$gp121 = $row["SireID"];$gp122 = $row["DamID"];}
		}
		if(!($gp111 == ""))
		{
			$sqlgp5 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp111."'";
			$querygp5 = mysql_query($sqlgp5, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp5))
			{extract($row);$gp1111 = $row["SireID"];$gp1112 = $row["DamID"];}
		}
		if(!($gp112 == ""))
		{
			$sqlgp6 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp112."'";
			$querygp6 = mysql_query($sqlgp6, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp6))
			{extract($row);$gp1121 = $row["SireID"];$gp1122 = $row["DamID"];}
		}
		if(!($gp121 == ""))
		{
			$sqlgp7 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp121."'";
			$querygp7 = mysql_query($sqlgp7, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp7))
			{extract($row);$gp1211 = $row["SireID"];$gp1212 = $row["DamID"];}
			echo $sqlgp7."<br/>";
		}
		if(!($gp122 == ""))
		{
			$sqlgp8 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp122."'";
			$querygp8 = mysql_query($sqlgp8, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp8))
			{extract($row);$gp1221 = $row["SireID"];$gp1222 = $row["DamID"];}
		}
		if(!($gp21 == ""))
		{
			$sqlgp9 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp21."'";
			$querygp9 = mysql_query($sqlgp9, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp9))
			{extract($row);$gp211 = $row["SireID"];$gp212 = $row["DamID"];}
		}
		if(!($gp22 == ""))
		{
			$sqlgp10 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp22."'";
			$querygp10 = mysql_query($sqlgp10, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp10))
			{extract($row);$gp221 = $row["SireID"];$gp222 = $row["DamID"];}
		}
		if(!($gp211 == ""))
		{
			$sqlgp11 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp211."'";
			$querygp11 = mysql_query($sqlgp11, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp11))
			{extract($row);$gp2111 = $row["SireID"];$gp2112 = $row["DamID"];}
		}
		if(!($gp212 == ""))
		{
			$sqlgp12 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp212."'";
			$querygp12 = mysql_query($sqlgp12, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp12))
			{extract($row);$gp2121 = $row["SireID"];$gp2122 = $row["DamID"];}
		}
		if(!($gp221 == ""))
		{
			$sqlgp13 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp221."'";
			$querygp13 = mysql_query($sqlgp13, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp13))
			{extract($row);$gp2211 = $row["SireID"];$gp2212 = $row["DamID"];}
		}
		if(!($gp222 == ""))
		{
			$sqlgp14 = "SELECT SireID, DamID FROM Pedigree WHERE AnimalID='".$gp222."'";
			$querygp14 = mysql_query($sqlgp14, $connect) or die(mysql_error());
			while($row = mysql_fetch_assoc($querygp14))
			{extract($row);$gp2221 = $row["SireID"];$gp2222 = $row["DamID"];}
		}
	}
	elseif($idtype == "angusreg")
	{
	
	}
	elseif($idtype == "isubpid")
	{
	
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="well">
		<h2>Single Animal Pedigree</h2>
		<form action="pedigree_view.php" method="post" enctype="multipart/form-data">
    		<select name="idType">
    			<option value="">Select an ID type</option>
    			<option value="intid">International ID</option>
    			<option value="angusreg">Angus Registration Number</option>
    			<option value="isubpid">ISUBP ID</option>
    		</select>
    		<br/>
    		<input class="form-control" type="text" name="animalid" id="animalid" placeholder="AnimalID"><br/>
    		<input class="btn" type="submit" name="search" id="search" value="Get Pedigree" />
    	</form>
	</div>
	<?php if(array_key_exists('search', $_POST)){ ?>
	<div class="well">
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1111; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp111; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1112; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-4"><?php echo $gp11; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1121; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp112; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1122; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-2"><?php echo $parent1; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1211; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp121; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1212; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-4"><?php echo $gp12; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1221; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp122; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp1222; ?></div></div>
    	<div class="row"><div class="col-md-2"><?php echo $animal; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2111; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp211; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2112; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-4"><?php echo $gp21; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2121; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp212; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2122; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-2"><?php echo $parent2; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2211; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp221; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2212; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-4"><?php echo $gp22; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2221; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-6"><?php echo $gp222; ?></div></div>
    	<div class="row"><div class="col-md-2 col-md-offset-8"><?php echo $gp2222; ?></div></div>
	</div>
	<?php } ?>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>