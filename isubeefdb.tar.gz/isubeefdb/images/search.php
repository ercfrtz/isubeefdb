<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

$nextYear = date(Y) + 1;
$measurementsArray = array();
$measurementsCount = 0;
$currentTime = time();
$fileName = '/tmp/ISUBEEFDB.'.$currentTime.'.txt';
$fileHandle = fopen($fileName,w) or die('Cannot open file: '.$fileName);
fwrite($fileHandle, "AnimalID\tDate\tValue\n");

$measurementarray = array();
$sqlmeasurements = "SELECT MeasurementID, MeasurementType FROM Measurements";
$querymeasurements = mysql_query($sqlmeasurements, $connect) or die(mysql_error());
while($row = mysql_fetch_assoc($querymeasurements))
{
	extract($row);
    $measurementid = $row["MeasurementID"];
    $measurementtype = $row["MeasurementType"];
    $tmpmeasurement = array($measurementid, $measurementtype);
    $measurementarray[] = $tmpmeasurement;
}


$sqlMeasurements = "SELECT * from Measurements";
$resultsMeasurements = mysql_query($sqlMeasurements,$connect) or die(mysql_error());
while($rowMeasurements = mysql_fetch_array($resultsMeasurements))
{
	$measurementsArray[$measurementsCount] = $rowMeasurements['MeasurementID']."\t".$rowMeasurements['MeasurementType'];
	$measurementsCount++;	
}

if(array_key_exists('search', $_POST))
{
	$measurement_list = $_POST['measurement_checkbox'];
	$year_list = $_POST['year_checkbox'];
	
	$traitArray = array();
	$traitCount = 0;
	
	if(in_array("birthweight", $measurement_list))
	{
		$traitName = "Birth Weight";
		
		if(in_array("all", $year_list))
		{
			$sqlBW = "SELECT * FROM SizeMeasurements WHERE MeasurementID='5' and SDID='1'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
			{
				$traitArray[$traitCount] = $rowBW['AnimalID']."\t".$rowBW['Date']."\t".$rowBW['Value'];
				$fileOutput = $rowBW['AnimalID']."\t".$rowBW['Date']."\t".$rowBW['Value'];
				fwrite($fileHandle, $fileOutput."\n");
				$traitCount++;
			}
		}
		else
		{
			foreach($year_list as $tempYear)
			{
				$dateBegin = ($tempYear-1)."-12-31";
				$dateEnd = ($tempYear+1)."-01-01";
				$sqlBW = "SELECT * FROM SizeMeasurements WHERE MeasurementID='5' and SDID='1' and Date>'".$dateBegin."' and Date<'".$dateEnd."'";
				$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
				while($rowBW = mysql_fetch_array($resultsBW))
				{
					$traitArray[$traitCount] = $rowBW['AnimalID']."\t".$rowBW['Date']."\t".$rowBW['Value'];
					$fileOutput = $rowBW['AnimalID']."\t".$rowBW['Date']."\t".$rowBW['Value'];
					fwrite($fileHandle, $fileOutput."\n");
					$traitCount++;
				}
			}
		}
	}
	else
	{
		if(in_array("all", $measurement_list))
		{
			if(in_array("all", $year_list))
			{
				$sqlName = "SELECT * FROM Measurements";
				$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
				while($rowName = mysql_fetch_array($resultsName))
				{
					$tempID = $rowName['MeasurementID'];
					$tempType = $rowName['MeasurementType'];
		
					$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempID."'";
					$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
					while($rowTrait = mysql_fetch_array($resultsTrait))
					{
						$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						$fileOutput = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						fwrite($fileHandle, $fileOutput."\n");
						$traitCount++;
					}
				}
			}
			else
			{
				foreach($year_list as $tempYear)
				{
					$dateBegin = ($tempYear-1)."-12-31";
					$dateEnd = ($tempYear+1)."-01-01";
					$sqlName = "SELECT * FROM Measurements";
					$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
					while($rowName = mysql_fetch_array($resultsName))
					{
						$tempID = $rowName['MeasurementID'];
						$tempType = $rowName['MeasurementType'];
				
						$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempID."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.BirthDate>'".$dateBegin."' and p.BirthDate<'".$dateEnd."')";
						$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
						while($rowTrait = mysql_fetch_array($resultsTrait))
						{
							$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							$fileOutput = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							fwrite($fileHandle, $fileOutput."\n");
							$traitCount++;
						}
					}
				}
			}
		}
		else
		{
			foreach($measurement_list as $tempM)
			{
				if(in_array("all", $year_list))
				{
					$sqlName = "SELECT MeasurementType FROM Measurements where MeasurementID='".$tempM."'";
					$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
					$rowName = mysql_fetch_array($resultsName);
					$traitName = $rowName['MeasurementType'];
		
					$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempM."'";
					$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
					while($rowTrait = mysql_fetch_array($resultsTrait))
					{
						$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						$fileOutput = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						fwrite($fileHandle, $fileOutput."\n");
						$traitCount++;
					}
				}
				else
				{
					foreach($year_list as $tempYear)
					{
						$sqlName = "SELECT MeasurementType FROM Measurements where MeasurementID='".$tempM."'";
						$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
						$rowName = mysql_fetch_array($resultsName);
						$traitName = $rowName['MeasurementType'];
						$dateBegin = ($tempYear-1)."-12-31";
						$dateEnd = ($tempYear+1)."-01-01";
		
						$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempM."' and AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.BirthDate>'".$dateBegin."' and p.BirthDate<'".$dateEnd."')";
						$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
						while($rowTrait = mysql_fetch_array($resultsTrait))
						{
							$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							$fileOutput = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							fwrite($fileHandle, $fileOutput."\n");
							$traitCount++;
						}
					}
				}
			}
		}
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Search</h1>
    	</div>
    	<div class="well">
    		<form class="form-horizontal" action="search.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    			<div class="panel"><br/>
    				<h2>Data Format:</h2>
            		<div class="row"><div class="col-md-2"><input type="radio" name="format" value="list" checked>Default List</div></div>
            		<div class="row"><div class="col-md-2"><input type="radio" name="format" value="excel">Excel (tab delimited)</div></div>
            	</div>
    			<div class="panel"><br/>
    				<h2>Birth Year:</h2>
    				<ul class="list-inline">
            			<div class="row"><li class="col-md-2"><input type="checkbox" name="year_checkbox[]" value="all">All</li>
            		<?php 
            			$rowCount = 2;
            			for($i = 1998; $i < $nextYear; $i++)
            			{
            				if($rowCount == 1)
            				{
            					echo '<div class="row"><li class="col-md-2"> <input type="checkbox" name="year_checkbox[]" value="'.$i.'"> '.$i.'</li>';
            					$rowCount++;
            				}
            				elseif($rowCount > 1 && $rowCount < 6)
            				{
            					echo '<li class="col-md-2"> <input type="checkbox" name="year_checkbox[]" value="'.$i.'"> '.$i.'</li>';
            					$rowCount++;
            				}
            				elseif($rowCount == 6)
            				{
            					echo '<li class="col-md-2"> <input type="checkbox" name="year_checkbox[]" value="'.$i.'"> '.$i.'</li></div>';
            					$rowCount = 1;
            				}
            			} ?>
            			</ul>
            	</div>
            	<div class="panel"><br/>
              		<h2>Measurements:</h2>
              		<ul class="list-inline">
              			<div class="row">
            			<li class="col-md-4"><input type="checkbox" name="measurement_checkbox[]" value="all"> All</li>
            			<li class="col-md-4"><input type="checkbox" name="measurement_checkbox[]" value="birthweight"> Birth Weight</li>
            			<?php
            				$rowCount = 3;
            				for($k = 0; $k < count($measurementarray); $k++)
            				{
            					$measurementid = $measurementarray[$k][0];
            					$measurementtype = $measurementarray[$k][1];
            					if($rowCount == 1)
            					{
            					    echo '<div class="row"><li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid.'"> '.$measurementtype.'</li>';
            						$rowCount++;
            					}
            					elseif($rowCount == 2)
            					{
            					    echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid.'"> '.$measurementtype.'</li>';
            						$rowCount++;
            					}
            					elseif($rowCount == 3)
            					{
            					    echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid.'"> '.$measurementtype.'</li></div>';
            						$rowCount = 1;
            					}
            				}
            			?>
            		</ul>
            	</div>
            	<div class="form-group row">
            		<input class="btn btn-primary col-md-offset-4" type="submit" name="search" id="search" value="Search" />
            	</div>
    		</form>
    	</div>
    	<?php if(array_key_exists('search', $_POST)){ ?>
    	<div class="well">
    		<h2>Results</h2>
    		<div class="row">
    			<h4 class="col-md-2"><?php echo $traitName; ?></h4>
    			<a href="download.php?currFile=<?php echo $fileName; ?>" class="btn btn-primary col-md-offset-1">Download Data</a>
    		</div>
      		<table class="table-striped">
      			<tr>
      				<td class="col-md-1 text-center">Animal ID</td>
      				<td class="col-md-1 text-center">Measurement</td>
      				<td class="col-md-1 text-center">Date</td>
      				<td class="col-md-1 text-center">Value</td>
      			</tr>
      			<?php for($i = 0; $i < count($traitArray); $i++){ ?>
      				<tr>
      					<?php $tempTraitArray = explode("\t",$traitArray[$i]);?>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[0]; ?></td>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[1]; ?></td>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[2]; ?></td>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[3]; ?></td>
      				</tr>
      			<?php } ?>
      		</table>
    	</div>
    	<?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>