<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

if(array_key_exists('search', $_POST))
{
	$idtype = $_POST['idtype'];
	$outtype = $_POST['outtype'];
	$lookupid = $_POST['lookupid'];
	
	if($idtype == "intid")
	{
		if($outtype == "isubpid")
		{
			$sqlBW = "SELECT ISUBPID FROM Pedigree WHERE AnimalID='".$lookupid."'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
				{$searchoutput = $rowBW['ISUBPID'];}
		}
		elseif($outtype == "regnum")
		{
			$sqlBW = "SELECT AngusRegNum FROM Pedigree WHERE AnimalID='".$lookupid."'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
				{$searchoutput = $rowBW['AngusRegNum'];}
		}
	}
	elseif($idtype == "isubpid")
	{
		if($outtype == "intid")
		{
			$sqlBW = "SELECT AnimalID FROM Pedigree WHERE ISUBPID='".$lookupid."'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
				{$searchoutput = $rowBW['AnimalID'];}
		}
		elseif($outtype == "regnum")
		{
			$sqlBW = "SELECT AngusRegNum FROM Pedigree WHERE ISUBPID='".$lookupid."'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
				{$searchoutput = $rowBW['AngusRegNum'];}
		}
	}
	elseif($idtype == "regnum")
	{
		if($outtype == "intid")
		{
			$sqlBW = "SELECT AnimalID FROM Pedigree WHERE AngusRegNum='".$lookupid."'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
				{$searchoutput = $rowBW['AnimalID'];}
		}
		elseif($outtype == "isubpid")
		{
			$sqlBW = "SELECT ISUBPID FROM Pedigree WHERE AngusRegNum='".$lookupid."'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
				{$searchoutput = $rowBW['ISUBPID'];}
		}
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Animal ID Search</h1>
    	</div>
    	<div class="well">
    		<form class="form-horizontal" action="animal_search.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    			<div class="panel"><br/>
    				<h2>ID Type:</h2>
            		<div class="row"><div class="col-md-2"><input type="radio" name="idtype" value="intid" checked>International ID</div></div>
            		<div class="row"><div class="col-md-2"><input type="radio" name="idtype" value="isubpid">ISU BP ID</div></div>
            		<div class="row"><div class="col-md-2"><input type="radio" name="idtype" value="regnum">Angus Registration Number</div></div>
            		<br />
            		<h2>Output Type:</h2>
            		<div class="row"><div class="col-md-2"><input type="radio" name="outtype" value="intid" checked>International ID</div></div>
            		<div class="row"><div class="col-md-2"><input type="radio" name="outtype" value="isubpid">ISU BP ID</div></div>
            		<div class="row"><div class="col-md-2"><input type="radio" name="outtype" value="regnum">Angus Registration Number</div></div>
            		<br />
            		<input class="form-control" type="text" id="lookupid" name="lookupid" placeholder="ID">
            		<div class="form-group row">
            			<input class="btn btn-primary col-md-offset-4" type="submit" name="search" id="search" value="Search" />
            		</div>
            	</div>
            </form>
    	</div>
    	<?php if(array_key_exists('search', $_POST)){ ?>
    		<div class="well">	
    			<div class="panel"><br/>
    				<h3><?php echo $searchoutput; ?></h3>
            	</div>
            </div>
        <?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>