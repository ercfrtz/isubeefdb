<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

$intAnimalid = "";

if(array_key_exists('search', $_POST))
{
	$animal = $_POST["animalid"];
	$idtype = $_POST["idType"];
	
	if($idtype == "intid")
	{
		$intAnimalid = $animal;
	}
	elseif($idtype == "angusreg")
	{
		$sqlangusreg = "SELECT AnimalID FROM Pedigree WHERE AngusRegNum='".$animal."'";
		$queryangusreg = mysql_query($sqlangusreg, $connect) or die(mysql_error());
		while($row = mysql_fetch_assoc($queryangusreg))
		{
			extract($row);
			$intAnimalid = $row["AnimalID"];
		}
	}
	elseif($idtype == "isubpid")
	{
		$sqlangusreg = "SELECT AnimalID FROM Pedigree WHERE ISUBPID='".$animal."'";
		$queryangusreg = mysql_query($sqlangusreg, $connect) or die(mysql_error());
		while($row = mysql_fetch_assoc($queryangusreg))
		{
			extract($row);
			$intAnimalid = $row["AnimalID"];
		}
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well">
    		<h2>Single Animal Pedigree</h2>
			<form action="single_animal_search.php" method="post" enctype="multipart/form-data">
    			<select name="idType">
    				<option value="">Select an ID type</option>
    				<option value="intid">International ID</option>
    				<option value="angusreg">Angus Registration Number</option>
    				<option value="isubpid">ISUBP ID</option>
    			</select>
    			<br/>
    			<input class="form-control" type="text" name="animalid" id="animalid" placeholder="AnimalID"><br/>
    			<input class="btn" type="submit" name="search" id="search" value="Get Animal Info" />
    		</form>
    	</div>
    	<?php if(array_key_exists('search', $_POST)){ ?>
    		<div class="well">
    			<h2>Results</h2>
    			<?php if($intAnimalid == ""){ ?>
    				<h4>No Results Found For This Animal!</h4>
    			<?php } else { ?>
    				<h4>Pedigree</h4>
    				<?php
    					$sqlpedigree = "SELECT * FROM Pedigree WHERE AnimalID='".$intAnimalid."'";
						$querypedigree = mysql_query($sqlpedigree, $connect) or die(mysql_error());
						while($row = mysql_fetch_assoc($querypedigree))
						{
							extract($row);
							echo "<p>Animal ID: ".$row["AnimalID"]."</p>";
							echo "<p>Birth Date: ".$row["BirthDate"]."</p>";
							echo "<p>Weaning Date: ".$row["Weaning Date"]."</p>";
							echo "<p>Leave Date: ".$row["Leave Date"]."</p>";
							echo "<p>Slaughter Date: ".$row["SlaughterDate"]."</p>";
							echo "<p>Dam ID: ".$row["DamID"]."</p>";
							echo "<p>Sire ID: ".$row["SireID"]."</p>";
							echo "<p>Sex: ".$row["Sex"]."</p>";
							echo "<p>Location ID: ".$row["LocationID"]."</p>";
							echo "<p>Breed ID: ".$row["BreedID"]."</p>";
							echo "<p>Presentation: ".$row["Presentation"]."</p>";
							echo "<p>TW or ET: ".$row["TWorET"]."</p>";
							echo "<p>Remarks: ".$row["Remarks"]."</p>";
							echo "<p>Angus Reg Num: ".$row["AngusRegNum"]."</p>";
							echo "<p>Angus Bir Num: ".$row["AngusBirNum"]."</p>";
							echo "<p>Castrations/Ovarectom: ".$row["Castration_Ovarectom_Date"]."</p>";
							echo "<p>ISUBP ID: ".$row["ISUBPID"]."</p>";
							echo "<p>Pre Reg ID: ".$row["PreRegID"]."</p>";
							echo "<p>Health ID: ".$row["HealthID"]."</p>";
							echo "<p>Dummy ID: ".$row["DummyID"]."</p>";
							echo "<p>ISU Herd: ".$row["ISU"]."</p>";	
						}
    				?>
    				<br/><h4>Phenotypes</h4>
    				<table class="table">
    					<tr>
    						<td>Animal ID</td>
    						<td>Date</td>
    						<td>Measurement</td>
    						<td>Specific Date</td>
    						<td>Value</td>
    					</tr>
    				<?php
    					$sqlpheno = "SELECT * FROM SizeMeasurements WHERE AnimalID='".$intAnimalid."'";
						$querypheno = mysql_query($sqlpheno, $connect) or die(mysql_error());
						while($row = mysql_fetch_assoc($querypheno))
						{
							extract($row);
							echo "<tr>";
							echo "<td>".$row["AnimalID"]."</td>";
							echo "<td>".$row["Date"]."</td>";
							$sqlmid = "SELECT MeasurementType FROM Measurements WHERE MeasurementID='".$row["MeasurementID"]."'";
							$querymid = mysql_query($sqlmid, $connect) or die(mysql_error());
							while($row2 = mysql_fetch_assoc($querymid))
								{extract($row2);echo "<td>".$row2["MeasurementType"]."</td>";}
							$sqlsdid = "SELECT SpecificDate FROM SpecificDate WHERE SDID='".$row["SDID"]."'";
							$querysdid = mysql_query($sqlsdid, $connect) or die(mysql_error());
							$tempsdid = "";
							while($row2 = mysql_fetch_assoc($querysdid))
								{extract($row2);$tempsdid=$row2["SpecificDate"];}
							if($tempsdid == ""){echo "<td>NA</td>";}else{echo "<td>".$tempsdid."</td>";}
							$sqluid = "SELECT UnitsType FROM Units WHERE UnitsID='".$row["UnitsID"]."'";
							$queryuid = mysql_query($sqluid, $connect) or die(mysql_error());
							$tempunitstype = "";
							while($row2 = mysql_fetch_assoc($queryuid))
								{extract($row2);$tempunitstype = $row2["UnitsType"];}
							if($tempunitstype == ""){echo "<td>".$row["Value"]."</td>";}else{echo "<td>".$row["Value"]." ".$tempunitstype."</td>";}
							echo "</tr>";
						}
    				?>
    				</table>
    			<?php } ?>
    		</div>
    	<?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>