<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
	header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb');
	exit;
}

$_SESSION = array();
if(isset($_COOKIE[session_name()]))
{
	setcookie(session_name(), '', time()-86400, '/');
}
session_destroy();
header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
exit;
?>