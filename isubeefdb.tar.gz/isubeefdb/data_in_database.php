<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

$totalanimals = 0;
$totalisu = 0;
$totalext = 0;
$sqltotal = "SELECT * FROM Pedigree";
$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
while($fetchTotal = mysql_fetch_assoc($querytotal))
{$totalanimals++;}
$sqlisu = "SELECT * FROM Pedigree WHERE ISU='Y'";
$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
while($fetchisu = mysql_fetch_assoc($queryisu))
{$totalisu++;}
$sqlext = "SELECT * FROM Pedigree WHERE ISU='N'";
$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
while($fetchext = mysql_fetch_assoc($queryext))
{$totalext++;}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Data Totals</h1>
    	</div>
    	<div class="well">
    		<div class="panel"><br/>
    			<h3>Animal Counts</h3>
    			<h4>Total: <?php echo $totalanimals; ?></h4>
    			<h4>ISU: <?php echo $totalisu; ?></h4>
    			<h4>External: <?php echo $totalext; ?></h4>
            </div>
            <div class="well">
            	<table class="table">
            		<tr>
            			<td>Information</td>
            			<td>Total</td>
            			<td>ISU</td>
            			<td>External</td>
            		</tr>
            		<tr>
            			<?php
            				$siretotal=0; $sireisu=0; $sireext=0;
            				$sqltotal = "SELECT SireID FROM Pedigree";
							$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
							while($fetchTotal = mysql_fetch_assoc($querytotal))
								{if($fetchTotal['SireID'] != "."){$siretotal++;}}
							$sqlisu = "SELECT SireID FROM Pedigree WHERE ISU='Y'";
							$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
							while($fetchisu = mysql_fetch_assoc($queryisu))
								{if($fetchisu['SireID'] != "."){$sireisu++;}}
							$sqlext = "SELECT SireID FROM Pedigree WHERE ISU='N'";
							$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
							while($fetchext = mysql_fetch_assoc($queryext))
								{if($fetchext['SireID'] != "."){$sireext++;}}
            			?>
            			<td>Sire</td>
            			<td><?php echo $siretotal; ?>/<?php echo $totalanimals; ?></td>
            			<td><?php echo $sireisu; ?>/<?php echo $totalisu; ?></td>
            			<td><?php echo $sireext; ?>/<?php echo $totalext; ?></td>
            		</tr>
            		<tr>
            			<?php
            				$damtotal=0; $damisu=0; $damext=0;
            				$sqltotal = "SELECT DamID FROM Pedigree";
							$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
							while($fetchTotal = mysql_fetch_assoc($querytotal))
								{if($fetchTotal['DamID'] != "."){$damtotal++;}}
							$sqlisu = "SELECT DamID FROM Pedigree WHERE ISU='Y'";
							$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
							while($fetchisu = mysql_fetch_assoc($queryisu))
								{if($fetchisu['DamID'] != "."){$damisu++;}}
							$sqlext = "SELECT DamID FROM Pedigree WHERE ISU='N'";
							$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
							while($fetchext = mysql_fetch_assoc($queryext))
								{if($fetchext['DamID'] != "."){$damext++;}}
            			?>
            			<td>Dam</td>
            			<td><?php echo $damtotal; ?>/<?php echo $totalanimals; ?></td>
            			<td><?php echo $damisu; ?>/<?php echo $totalisu; ?></td>
            			<td><?php echo $damext; ?>/<?php echo $totalext; ?></td>
            		</tr>
            		<tr>
            			<?php
            				$bdtotal=0; $bdisu=0; $bdext=0;
            				$sqltotal = "SELECT BirthDate FROM Pedigree";
							$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
							while($fetchTotal = mysql_fetch_assoc($querytotal))
								{if($fetchTotal['BirthDate'] != "0000-00-00"){$bdtotal++;}}
							$sqlisu = "SELECT BirthDate FROM Pedigree WHERE ISU='Y'";
							$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
							while($fetchisu = mysql_fetch_assoc($queryisu))
								{if($fetchisu['BirthDate'] != "0000-00-00"){$bdisu++;}}
							$sqlext = "SELECT BirthDate FROM Pedigree WHERE ISU='N'";
							$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
							while($fetchext = mysql_fetch_assoc($queryext))
								{if($fetchext['BirthDate'] != "0000-00-00"){$bdext++;}}
            			?>
            			<td>Birth Date</td>
            			<td><?php echo $bdtotal; ?>/<?php echo $totalanimals; ?></td>
            			<td><?php echo $bdisu; ?>/<?php echo $totalisu; ?></td>
            			<td><?php echo $bdext; ?>/<?php echo $totalext; ?></td>
            		</tr>
            		<tr>
            			<?php
            				$hdtotal=0; $hdisu=0; $hdext=0;
            				$sqltotal = "SELECT SlaughterDate FROM Pedigree WHERE SlaughterDate IS NOT NULL";
							$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
							while($fetchTotal = mysql_fetch_assoc($querytotal))
								{$hdtotal++;}
							$sqlisu = "SELECT SlaughterDate FROM Pedigree WHERE ISU='Y' AND SlaughterDate IS NOT NULL";
							$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
							while($fetchisu = mysql_fetch_assoc($queryisu))
								{$hdisu++;}
							$sqlext = "SELECT SlaughterDate FROM Pedigree WHERE ISU='N' AND SlaughterDate IS NOT NULL";
							$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
							while($fetchext = mysql_fetch_assoc($queryext))
								{$hdext++;}
            			?>
            			<td>Harvest Date</td>
            			<td><?php echo $hdtotal; ?>/<?php echo $totalanimals; ?></td>
            			<td><?php echo $hdisu; ?>/<?php echo $totalisu; ?></td>
            			<td><?php echo $hdext; ?>/<?php echo $totalext; ?></td>
            		</tr>
            		<tr>
            			<?php
            				$sextotal=0; $sexisu=0; $sexext=0;
            				$sqltotal = "SELECT Sex FROM Pedigree WHERE Sex IS NOT NULL";
							$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
							while($fetchTotal = mysql_fetch_assoc($querytotal))
								{$sextotal++;}
							$sqlisu = "SELECT Sex FROM Pedigree WHERE ISU='Y' AND Sex IS NOT NULL";
							$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
							while($fetchisu = mysql_fetch_assoc($queryisu))
								{$sexisu++;}
							$sqlext = "SELECT Sex FROM Pedigree WHERE ISU='N' AND Sex IS NOT NULL";
							$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
							while($fetchext = mysql_fetch_assoc($queryext))
								{$sexext++;}
            			?>
            			<td>Sex</td>
            			<td><?php echo $sextotal; ?>/<?php echo $totalanimals; ?></td>
            			<td><?php echo $sexisu; ?>/<?php echo $totalisu; ?></td>
            			<td><?php echo $sexext; ?>/<?php echo $totalext; ?></td>
            		</tr>
            		<?php
            			$sqlgenotype = "SELECT PlatformID, PlatformName FROM GeneticsPlatforms";
						$querygenotype = mysql_query($sqlgenotype, $connect) or die(mysql_error());
						while($row = mysql_fetch_assoc($querygenotype))
						{
							extract($row);
    						$platformid = $row["PlatformID"];
    						$platformname = $row["PlatformName"];
    				?>
    					<tr>
    						<?php
    							$genotypetotal=0; $genotypeisu=0; $genotypeext=0;
    							$sqltotal = "SELECT DISTINCT(AnimalID) FROM GeneticsPlatformData WHERE PlatformID='".$platformid."'";
								$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
								while($fetchTotal = mysql_fetch_assoc($querytotal))
									{$genotypetotal++;}
								$sqlisu = "SELECT DISTINCT(AnimalID) FROM GeneticsPlatformData WHERE PlatformID='".$platformid."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.ISU='Y')";
								$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
								while($fetchisu = mysql_fetch_assoc($queryisu))
									{$genotypeisu++;}
								$sqlext = "SELECT DISTINCT(AnimalID) FROM GeneticsPlatformData WHERE PlatformID='".$platformid."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.ISU='N')";
								$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
								while($fetchext = mysql_fetch_assoc($queryext))
									{$genotypeext++;}
    						?>
							<td><?php echo $platformname; ?></td>
							<td><?php echo $genotypetotal; ?>/<?php echo $totalanimals; ?></td>
            				<td><?php echo $genotypeisu; ?>/<?php echo $totalisu; ?></td>
            				<td><?php echo $genotypeext; ?>/<?php echo $totalext; ?></td>
            			</tr>
					<?php } ?>
					<tr>
    						<?php
    							$genotypetotal=0; $genotypeisu=0; $genotypeext=0;
    							$sqltotal = "SELECT DISTINCT(AnimalID) FROM GeneticsPlatformData";
								$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
								while($fetchTotal = mysql_fetch_assoc($querytotal))
									{$genotypetotal++;}
								$sqlisu = "SELECT DISTINCT(AnimalID) FROM GeneticsPlatformData WHERE AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.ISU='Y')";
								$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
								while($fetchisu = mysql_fetch_assoc($queryisu))
									{$genotypeisu++;}
								$sqlext = "SELECT DISTINCT(AnimalID) FROM GeneticsPlatformData WHERE AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.ISU='N')";
								$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
								while($fetchext = mysql_fetch_assoc($queryext))
									{$genotypeext++;}
    						?>
							<td>All Platforms</td>
							<td><?php echo $genotypetotal; ?>/<?php echo $totalanimals; ?></td>
            				<td><?php echo $genotypeisu; ?>/<?php echo $totalisu; ?></td>
            				<td><?php echo $genotypeext; ?>/<?php echo $totalext; ?></td>
            			</tr>
            		<?php
            			$sqlmeasurements = "SELECT MeasurementID, MeasurementType FROM Measurements";
						$querymeasurements = mysql_query($sqlmeasurements, $connect) or die(mysql_error());
						while($row = mysql_fetch_assoc($querymeasurements))
						{
							extract($row);
    						$measurementid = $row["MeasurementID"];
    						$measurementname = $row["MeasurementType"];
    				?>
    					<tr>
    						<?php
    							$measuretotal=0; $measureisu=0; $measureext=0;
    							$sqltotal = "SELECT DISTINCT(AnimalID) FROM SizeMeasurements WHERE MeasurementID='".$measurementid."'";
								$querytotal = mysql_query($sqltotal, $connect) or die(mysql_error());
								while($fetchTotal = mysql_fetch_assoc($querytotal))
									{$measuretotal++;}
								$sqlisu = "SELECT DISTINCT(AnimalID) FROM SizeMeasurements WHERE MeasurementID='".$measurementid."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.ISU='Y')";
								$queryisu = mysql_query($sqlisu, $connect) or die(mysql_error());
								while($fetchisu = mysql_fetch_assoc($queryisu))
									{$measureisu++;}
								$sqlext = "SELECT DISTINCT(AnimalID) FROM SizeMeasurements WHERE MeasurementID='".$measurementid."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.ISU='N')";
								$queryext = mysql_query($sqlext, $connect) or die(mysql_error());
								while($fetchext = mysql_fetch_assoc($queryext))
									{$measureext++;}
    						?>
							<td><?php echo $measurementname; ?></td>
							<td><?php echo $measuretotal; ?>/<?php echo $totalanimals; ?></td>
            				<td><?php echo $measureisu; ?>/<?php echo $totalisu; ?></td>
            				<td><?php echo $measureext; ?>/<?php echo $totalext; ?></td>
            			</tr>
					<?php } ?>
            	</table>
            </div>
    	</div>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>