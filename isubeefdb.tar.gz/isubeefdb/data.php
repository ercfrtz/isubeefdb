<?php
session_start();

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("EpiDB");

$speciesSNameArray = array();
$speciesCNameArray = array();
$speciesImageArray = array();
$speciesRNAseqCountArray = array();
$speciesMethlycationCountArray = array();
$speciesmiRNACountArray = array();
$speciesChIPseqCountArray = array();
$speciesCount = 0;

$sql = "SELECT * FROM EpiDB_Species";
$results = mysql_query($sql,$connect) or die(mysql_error());
while($row = mysql_fetch_array($results))
{
	$speciesID = $row['species_ID'];
	$speciesSNameArray[$speciesCount] = $row['species_sname'];
	$speciesCNameArray[$speciesCount] = $row['species_cname'];
	$speciesImageArray[$speciesCount] = $row['Image'];
	$speciesRNAseqCountArray[$speciesCount] = 0;
	$speciesMethCountArray[$speciesCount] = 0;
	$speciesmiRNACountArray[$speciesCount] = 0;
	$speciesChIPseqCountArray[$speciesCount] = 0;
	$speciesTissueCountArray[$speciesCount] = 0;
	
	$sqlRNAseq = "SELECT * FROM EpiDB_rnaseq_track WHERE species_ID='$speciesID'";
	$resultsRNAseq = mysql_query($sqlRNAseq,$connect) or die(mysql_error());
	while($rowRNAseq = mysql_fetch_array($resultsRNAseq))
	{
		$speciesRNAseqCountArray[$speciesCount]++;
	}
	$sqlMethseq = "SELECT * FROM EpiDB_Methyl_track WHERE species_ID='$speciesID'";
	$resultsMethseq = mysql_query($sqlMethseq,$connect) or die(mysql_error());
	while($rowMethseq = mysql_fetch_array($resultsMethseq))
	{
		$speciesMethCountArray[$speciesCount]++;
	}
	$sqlmiRNA = "SELECT * FROM EpiDB_miRNA_track WHERE species_ID='$speciesID'";
	$resultsmiRNA = mysql_query($sqlmiRNA,$connect) or die(mysql_error());
	while($rowmiRNA = mysql_fetch_array($resultsmiRNA))
	{
		$speciesmiRNACountArray[$speciesCount]++;
	}
	$sqlChIPseq = "SELECT * FROM EpiDB_chipseq_track WHERE species_ID='$speciesID'";
	$resultsChIPseq = mysql_query($sqlChIPseq,$connect) or die(mysql_error());
	while($rowChIPseq = mysql_fetch_array($resultsChIPseq))
	{
		$speciesChIPseqCountArray[$speciesCount]++;
	}
	
	$tempTissueArray = array();
	$tissueCount = 0;
	$sqlTissue = "SELECT * from EpiDB_Tissues";
	$resultsTissue = mysql_query($sqlTissue,$connect) or die(mysql_error());
	while($rowTissue = mysql_fetch_array($resultsTissue))
	{
		$tempTissueArray[$count] = 0;
		$count++;
	}
	$sqlRNAseq = "SELECT DISTINCT tissue_ID FROM EpiDB_rnaseq_track WHERE species_ID='$speciesID'";
	$resultsRNAseq = mysql_query($sqlRNAseq,$connect) or die(mysql_error());
	while($rowRNAseq = mysql_fetch_array($resultsRNAseq))
	{
		$tempID = $rowRNAseq['tissue_ID'];
		$tempTissueArray[$tempID-1] = 1;
	}
	$sqlMethseq = "SELECT DISTINCT tissue_ID FROM EpiDB_Methyl_track WHERE species_ID='$speciesID'";
	$resultsMethseq = mysql_query($sqlMethseq,$connect) or die(mysql_error());
	while($rowMethseq = mysql_fetch_array($resultsMethseq))
	{
		$tempID = $rowMethseq['tissue_ID'];
		$tempTissueArray[$tempID-1] = 1;
	}
	$sqlmiRNA = "SELECT DISTINCT tissue_ID FROM EpiDB_miRNA_track WHERE species_ID='$speciesID'";
	$resultsmiRNA = mysql_query($sqlmiRNA,$connect) or die(mysql_error());
	while($rowmiRNA = mysql_fetch_array($resultsmiRNA))
	{
		$tempID = $rowmiRNA['tissue_ID'];
		$tempTissueArray[$tempID-1] = 1;
	}
	$sqlChIPseq = "SELECT DISTINCT tissue_ID FROM EpiDB_chipseq_track WHERE species_ID='$speciesID'";
	$resultsChIPseq = mysql_query($sqlChIPseq,$connect) or die(mysql_error());
	while($rowChIPseq = mysql_fetch_array($resultsChIPseq))
	{
		$tempID = $rowChIPseq['tissue_ID'];
		$tempTissueArray[$tempID-1] = 1;
	}
	for($i = 0; $i < count($tempTissueArray); $i++)
	{
		$speciesTissueCountArray[$speciesCount] += $tempTissueArray[$i];
	}
	$speciesCount++;
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EpiDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="js/createAjaxObject.js" type="text/javascript" language="javascript"></script>
<script src="js/logincheck.js" type="text/javascript" language="javascript"></script>
<script src="js/jquery.js" type="text/javascript" language="javascript"></script>
<script src="js/bootstrap.js" type="text/javascript" language="javascript"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Data</h1>
    	</div>
    	<div class="well">
    		<h2>Species</h2>
    		<?php
    			for($i = 0; $i < count($speciesSNameArray); $i++)
    			{
    		?>
    			<div class="panel row">
    				<div class="col-md-1">
    					<img src="<?php echo $speciesImageArray[$i]; ?>" />
    				</div>
    				<div class="col-md-9 col-md-offset-1">
    					<br/><h3><?php echo $speciesSNameArray[$i]." (".$speciesCNameArray[$i].")"; ?>:</h3>
    					<h4>There have been <?php echo $speciesRNAseqCountArray[$i]; ?> RNAseq datasets, <?php echo $speciesMethCountArray[$i]; ?> methylation datasets, <?php echo $speciesmiRNACountArray[$i]; ?> miRNA datasets, and <?php echo $speciesChIPseqCountArray[$i]; ?> ChIPseq datasets loaded into the database, spanning <?php echo $speciesTissueCountArray[$i]; ?> tissues.</h4>
    				</div>
    			</div>
    		<?php
    			}
    		?>
    	</div>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>