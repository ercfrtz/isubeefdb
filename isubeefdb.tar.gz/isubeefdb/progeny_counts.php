<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Progeny Totals</h1>
    	</div>
    	<div class="well">
            <h3>Sires</h3>
            <table class="table">
            	<tr>
            		<td>Animal ID</td>
            		<td>Progeny Total</td>
            	</tr>
            	<?php
            		$sqlsire = "SELECT SireID, count(SireID) FROM Pedigree GROUP BY SireID";
					$querysire = mysql_query($sqlsire, $connect) or die(mysql_error());
					while($fetchsire = mysql_fetch_assoc($querysire))
					{
						if(strpos($fetchsire['SireID'],'AANUSA') !== false)
						{
            	?>
            		<tr>
            			<?php foreach($fetchsire as $value){ ?>
            				<td><?php echo $value; ?></td>
            			<?php } ?>
            		</tr>
            	<?php } } ?>
            </table>
    	</div>
    	<div class="well">
            <h3>Dams</h3>
            <table class="table">
            	<tr>
            		<td>Animal ID</td>
            		<td>Progeny Total</td>
            	</tr>
            	<?php
            		$sqldam = "SELECT DamID, count(DamID) FROM Pedigree GROUP BY DamID";
					$querydam = mysql_query($sqldam, $connect) or die(mysql_error());
					while($fetchdam = mysql_fetch_assoc($querydam))
					{
						if(strpos($fetchdam['DamID'],'AANUSA') !== false)
						{
            	?>
            		<tr>
            			<?php foreach($fetchdam as $value){ ?>
            				<td><?php echo $value; ?></td>
            			<?php } ?>
            		</tr>
            	<?php } } ?>
            </table>
    	</div>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>