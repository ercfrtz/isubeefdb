<?php
session_start();
if(!isset($_SESSION['authenticated']))
{
  header('Location: http://nagrp.ansci.iastate.edu/eric/isubeefdb/');
  exit;
}

include('includes/title.inc.php');

$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
mysql_select_db("isubeefdb");

$nextYear = date(Y) + 1;
$measurementsArray = array();
$measurementsCount = 0;
$currentTime = time();
$fileName = '/tmp/ISUBEEFDB.'.$currentTime.'.txt';
$fileHandle = fopen($fileName,w) or die('Cannot open file: '.$fileName);

$measurementarray = array();
$sqlmeasurements = "SELECT * FROM Measurements";
$querymeasurements = mysql_query($sqlmeasurements, $connect) or die(mysql_error());
while($row = mysql_fetch_assoc($querymeasurements))
{
	extract($row);
    $measurementid = $row["MeasurementID"];
    $measurementtype = $row["MeasurementType"];
    $measurementmult = $row["Multiple"];
    
    if($measurementmult == "Y")
    {
    	$sqlSDIDcheck = "SELECT DISTINCT SDID from SizeMeasurements WHERE MeasurementID='".$measurementid."'";
    	$querySDIDcheck = mysql_query($sqlSDIDcheck, $connect) or die(mysql_error());
    	$resultsSDIDcheck = array();
    	while($row = mysql_fetch_assoc($querySDIDcheck))
    	{
    		$resultsSDIDcheck[] = $row['SDID'];
    	}
    	if(count($resultsSDIDcheck) > 0)
    	{
    		for($i = 0; $i < count($resultsSDIDcheck); $i++)
    		{
    			if($resultsSDIDcheck[$i] == 1 || $resultsSDIDcheck[$i] == 2 || $resultsSDIDcheck[$i] == 3)
    			{
    				$measurementsdid = $resultsSDIDcheck[$i];
    				$tmpmeasurement = array($measurementid, $measurementtype, $measurementsdid);
    				$measurementarray[] = $tmpmeasurement;
    			}
    		}
    	}
    }
    elseif($measurementmult == "N")
    {
    	$measurementsdid = 0;
    	$tmpmeasurement = array($measurementid, $measurementtype, $measurementsdid);
    	$measurementarray[] = $tmpmeasurement;
    }
}


$sqlMeasurements = "SELECT * from Measurements";
$resultsMeasurements = mysql_query($sqlMeasurements,$connect) or die(mysql_error());
while($rowMeasurements = mysql_fetch_array($resultsMeasurements))
{
	$measurementsArray[$measurementsCount] = $rowMeasurements['MeasurementID']."\t".$rowMeasurements['MeasurementType'];
	$measurementsCount++;	
}

if(array_key_exists('search', $_POST))
{
	$measurement_list = $_POST['measurement_checkbox'];
	$year_list = $_POST['year_checkbox'];
	$dataformat = $_POST['format'];
	
	$traitArray = array();
	$traitCount = 0;
	
	if($dataformat == "list")
	{
		fwrite($fileHandle, "AnimalID\tDate\tValue\n");
		if(in_array("all", $measurement_list))
		{
			if(in_array("all", $year_list))
			{
				for($i = 0; $i < count($measurementarray); $i++)
				{
					$tempID = $measurementarray[$i][0];
					$tempType = $measurementarray[$i][1];
					$tempSDID = $measurementarray[$i][2];
		
					if($tempSDID > 0)
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempID."' AND SDID='".$tempSDID."'";}
					else
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempID."'";}
					$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
					while($rowTrait = mysql_fetch_array($resultsTrait))
					{
						$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						$fileOutput = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						fwrite($fileHandle, $fileOutput."\n");
						$traitCount++;
					}
				}
			}
			else
			{
				foreach($year_list as $tempYear)
				{
					$dateBegin = ($tempYear-1)."-12-31";
					$dateEnd = ($tempYear+1)."-01-01";
					for($i = 0; $i < count($measurementarray); $i++)
					{
						$tempID = $measurementarray[$i][0];
						$tempType = $measurementarray[$i][1];
						$tempSDID = $measurementarray[$i][2];
				
						if($tempSDID > 0)
							{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempID."' AND SDID='".$tempSDID."' AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.BirthDate>'".$dateBegin."' and p.BirthDate<'".$dateEnd."')";}
						else
							{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempID."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.BirthDate>'".$dateBegin."' and p.BirthDate<'".$dateEnd."')";}
						$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
						while($rowTrait = mysql_fetch_array($resultsTrait))
						{
							$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							$fileOutput = $rowTrait['AnimalID']."\t".$tempType."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							fwrite($fileHandle, $fileOutput."\n");
							$traitCount++;
						}
					}
				}
			}
		}
		else
		{
			foreach($measurement_list as $tempM)
			{
				if(in_array("all", $year_list))
				{
					$tempMSplit = explode("_",$tempM);
					$sqlName = "SELECT MeasurementType FROM Measurements where MeasurementID='".$tempMSplit[0]."'";
					$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
					$rowName = mysql_fetch_array($resultsName);
					$traitName = $rowName['MeasurementType'];
		
					if($tempMSplit[1] > 0)
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempMSplit[0]."' AND SDID='".$tempMSplit[1]."'";}
					else
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempMSplit[0]."'";}
					$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
					while($rowTrait = mysql_fetch_array($resultsTrait))
					{
						$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						$fileOutput = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
						fwrite($fileHandle, $fileOutput."\n");
						$traitCount++;
					}
				}
				else
				{
					foreach($year_list as $tempYear)
					{
						$tempMSplit = explode("_",$tempM);
						$sqlName = "SELECT MeasurementType FROM Measurements where MeasurementID='".$tempMSplit[0]."'";
						$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
						$rowName = mysql_fetch_array($resultsName);
						$traitName = $rowName['MeasurementType'];
						$dateBegin = ($tempYear-1)."-12-31";
						$dateEnd = ($tempYear+1)."-01-01";
		
						if($tempMSplit[1] > 0)
							{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempMSplit[0]."' AND SDID='".$tempMSplit[1]."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.BirthDate>'".$dateBegin."' and p.BirthDate<'".$dateEnd."')";}
						else
							{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE MeasurementID='".$tempMSplit[0]."' AND AnimalID in(SELECT p.AnimalID FROM Pedigree p where p.BirthDate>'".$dateBegin."' and p.BirthDate<'".$dateEnd."')";}
						$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
						while($rowTrait = mysql_fetch_array($resultsTrait))
						{
							$traitArray[$traitCount] = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							$fileOutput = $rowTrait['AnimalID']."\t".$traitName."\t".$rowTrait['Date']."\t".$rowTrait['Value'];
							fwrite($fileHandle, $fileOutput."\n");
							$traitCount++;
						}
					}
				}
			}
		}
	}
	elseif($dataformat == "excel")
	{
		$tempAnimalArray = array();
		$headerArray = array();
		$headerArray["animal"] = "Animal";
		if(in_array("all", $year_list))
		{
			$sqlBW = "SELECT AnimalID FROM Pedigree WHERE ISU='Y'";
			$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
			while($rowBW = mysql_fetch_array($resultsBW))
			{
				$tempAID = $rowBW['AnimalID'];
				$tempAnimalArray[$tempAID] = $tempAID;
			}
		}
		else
		{
			foreach($year_list as $tempYear)
			{
				$dateBegin = ($tempYear-1)."-12-31";
				$dateEnd = ($tempYear+1)."-01-01";
				$sqlBW = "SELECT AnimalID FROM Pedigree WHERE BirthDate>'".$dateBegin."' and BirthDate<'".$dateEnd."'";
				$resultsBW = mysql_query($sqlBW,$connect) or die(mysql_error());
				while($rowBW = mysql_fetch_array($resultsBW))
				{
					$tempAID = $rowBW['AnimalID'];
					$tempAnimalArray[$tempAID] = $tempAID;
				}
			}
		}
		foreach($tempAnimalArray as $animal)
		{
			if(in_array("all", $measurement_list))
			{
				for($i = 0; $i < count($measurementarray); $i++)
				{
					$tempID = $measurementarray[$i][0];
					$tempType = $measurementarray[$i][1];
					$tempSDID = $measurementarray[$i][2];
					$sqlName = "SELECT MeasurementType FROM Measurements where MeasurementID='".$tempType."'";
					$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
					$rowName = mysql_fetch_array($resultsName);
					$traitName = $rowName['MeasurementType'];
					$sqlDate = "SELECT SpecificDate FROM SpecificDate WHERE SDID='".$tempSDID."'";
					$resultsDate = mysql_query($sqlDate,$connect) or die(mysql_error());
					$rowDate = mysql_fetch_array($resultsDate);	
					$specDate = $rowDate['SpecificDate'];
					$tempName = $traitName."_".$specDate;
					$tempCombo = $tempType."_".$tempSDID;
						
					$headerArray[$tempName] = $tempName;
					$traitArray[$animal][$tempCombo] = "NA";
					if($tempSDID > 0)
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE AnimalID='".$animal."' AND MeasurementID='".$tempID."' AND SDID='".$tempSDID."'";}
					else
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE AnimalID='".$animal."' AND MeasurementID='".$tempID."'";}
					$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
					while($rowTrait = mysql_fetch_array($resultsTrait))
					{
						if(!($rowTrait['Value'] == ""))
							{$traitArray[$animal][$tempCombo] = $rowTrait['Value'];}
					}	
				}
			}
			else
			{
				foreach($measurement_list as $tempM)
				{
					$tempMSplit = explode("_",$tempM);
					$sqlName = "SELECT MeasurementType FROM Measurements where MeasurementID='".$tempMSplit[0]."'";
					$resultsName = mysql_query($sqlName,$connect) or die(mysql_error());
					$rowName = mysql_fetch_array($resultsName);
					$traitName = $rowName['MeasurementType'];
					$sqlDate = "SELECT SpecificDate FROM SpecificDate WHERE SDID='".$tempMSplit[1]."'";
					$resultsDate = mysql_query($sqlDate,$connect) or die(mysql_error());
					$rowDate = mysql_fetch_array($resultsDate);	
					$specDate = $rowDate['SpecificDate'];
					$tempName = $traitName."_".$specDate;
						
					$headerArray[$tempName] = $tempName;
					$traitArray[$animal][$tempM] = "NA";
					if($tempMSplit[1] > 0)
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE AnimalID='".$animal."' AND MeasurementID='".$tempMSplit[0]."' AND SDID='".$tempMSplit[1]."'";}
					else
						{$sqlTrait = "SELECT * FROM SizeMeasurements WHERE AnimalID='".$animal."' AND MeasurementID='".$tempMSplit[0]."'";}
					$resultsTrait = mysql_query($sqlTrait,$connect) or die(mysql_error());
					while($rowTrait = mysql_fetch_array($resultsTrait))
					{
						if(!($rowTrait['Value'] == ""))
							{$traitArray[$animal][$tempM] = $rowTrait['Value'];}
					}
				}
			}
		}
		
		$headingCount = 1;
		foreach($headerArray as $heading)
		{
    		if($headingCount == 1)
    			{fwrite($fileHandle, $heading);$headingCount++;}
    		else
    			{fwrite($fileHandle, "\t".$heading);}
    	}
    	fwrite($fileHandle, "\n");
    	while($tempAnimal = current($traitArray))
    	{
    		fwrite($fileHandle, key($traitArray));
    		foreach($tempAnimal as $value)
    		{
    			fwrite($fileHandle, "\t".$value);
    		}
    		next($traitArray);
    		fwrite($fileHandle, "\n");
    	}
    	reset($traitArray);
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>ISUBEEFDB<?php if (isset($title)) {echo "&#8212;{$title}";} ?></title>
<link href="bootstrap.css" rel="stylesheet" type="text/css" />
<link href="bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>

<body>
<?php include('includes/header.inc.php'); ?>
<div class="container">
	<div class="panel panel-primary">
    	<div class="well text-center">
    		<h1>Search</h1>
    	</div>
    	<div class="well">
    		<form class="form-horizontal" action="search.php" method="post" enctype="multipart/form-data" name="searchForm" id="searchForm">
    			<div class="panel"><br/>
    				<h2>Data Format:</h2>
            		<div class="row"><div class="col-md-2"><input type="radio" name="format" value="list" checked>Default List</div></div>
            		<div class="row"><div class="col-md-2"><input type="radio" name="format" value="excel">Excel (tab delimited)</div></div>
            	</div>
    			<div class="panel"><br/>
    				<h2>Birth Year:</h2>
    				<ul class="list-inline">
            			<div class="row"><li class="col-md-2"><input type="checkbox" name="year_checkbox[]" value="all">All</li>
            		<?php 
            			$rowCount = 2;
            			for($i = 1998; $i < $nextYear; $i++)
            			{
            				if($rowCount == 1)
            				{
            					echo '<div class="row"><li class="col-md-2"> <input type="checkbox" name="year_checkbox[]" value="'.$i.'"> '.$i.'</li>';
            					$rowCount++;
            				}
            				elseif($rowCount > 1 && $rowCount < 6)
            				{
            					echo '<li class="col-md-2"> <input type="checkbox" name="year_checkbox[]" value="'.$i.'"> '.$i.'</li>';
            					$rowCount++;
            				}
            				elseif($rowCount == 6)
            				{
            					echo '<li class="col-md-2"> <input type="checkbox" name="year_checkbox[]" value="'.$i.'"> '.$i.'</li></div>';
            					$rowCount = 1;
            				}
            			} ?>
            			</ul>
            	</div>
            	<div class="panel"><br/>
              		<h2>Measurements:</h2>
              		<ul class="list-inline">
              			<div class="row">
            			<li class="col-md-4"><input type="checkbox" name="measurement_checkbox[]" value="all">All</li>
            			<?php
            				$rowCount = 2;
            				for($k = 0; $k < count($measurementarray); $k++)
            				{
            					$measurementid = $measurementarray[$k][0];
            					$measurementtype = $measurementarray[$k][1];
            					$measurementsdid = $measurementarray[$k][2];
            					if($rowCount == 1)
            					{
            					    if($measurementsdid == 0)
            					    {
            					    	echo '<div class="row"><li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.'</li>';
            							$rowCount++;
            					    }
            					    elseif($measurementsdid == 1)
            					    {
            					    	echo '<div class="row"><li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Birth)</li>';
            							$rowCount++;
            					    }
            					    elseif($measurementsdid == 2)
            					    {
            					    	echo '<div class="row"><li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Weaning)</li>';
            							$rowCount++;
            					    }
            					    elseif($measurementsdid == 3)
            					    {
            					    	echo '<div class="row"><li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Yearling)</li>';
            							$rowCount++;
            					    }
            					}
            					elseif($rowCount == 2)
            					{
            					    if($measurementsdid == 0)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.'</li>';
            							$rowCount++;
            					    }
            					    elseif($measurementsdid == 1)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Birth)</li>';
            							$rowCount++;
            					    }
            					    elseif($measurementsdid == 2)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Weaning)</li>';
            							$rowCount++;
            					    }
            					    elseif($measurementsdid == 3)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Yearling)</li>';
            							$rowCount++;
            					    }
            					}
            					elseif($rowCount == 3)
            					{
            					    if($measurementsdid == 0)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.'</li></div>';
            							$rowCount = 1;
            					    }
            					    elseif($measurementsdid == 1)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Birth)</li></div>';
            							$rowCount = 1;
            					    }
            					    elseif($measurementsdid == 2)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Weaning)</li></div>';
            							$rowCount = 1;
            					    }
            					    elseif($measurementsdid == 3)
            					    {
            					    	echo '<li class="col-md-4"> <input type="checkbox" name="measurement_checkbox[]" value="'.$measurementid."_".$measurementsdid.'"> '.$measurementtype.' (Yearling)</li></div>';
            							$rowCount = 1;
            					    }
            					}
            				}
            			?>
            		</ul>
            	</div>
            	<div class="form-group row">
            		<input class="btn btn-primary col-md-offset-4" type="submit" name="search" id="search" value="Search" />
            	</div>
    		</form>
    	</div>
    	<?php if(array_key_exists('search', $_POST) && ($_POST['format'] == "list")){ ?>
    	<div class="well">
    		<h2>Results</h2>
    		<div class="row">
    			<h4 class="col-md-2"><?php echo $traitName; ?></h4>
    			<a href="download.php?currFile=<?php echo $fileName; ?>" class="btn btn-primary col-md-offset-1">Download Data</a>
    		</div>
      		<table class="table-striped">
      			<tr>
      				<td class="col-md-1 text-center">Animal ID</td>
      				<td class="col-md-1 text-center">Measurement</td>
      				<td class="col-md-1 text-center">Date</td>
      				<td class="col-md-1 text-center">Value</td>
      			</tr>
      			<?php for($i = 0; $i < count($traitArray); $i++){ ?>
      				<tr>
      					<?php $tempTraitArray = explode("\t",$traitArray[$i]);?>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[0]; ?></td>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[1]; ?></td>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[2]; ?></td>
      					<td class="col-md-1 text-center"><?php echo $tempTraitArray[3]; ?></td>
      				</tr>
      			<?php } ?>
      		</table>
    	</div>
    	<?php } ?>
    	<?php if(array_key_exists('search', $_POST) && ($_POST['format'] == "excel")){ ?>
    	<div class="well">
    		<h2>Results</h2>
    		<h4>This option is still under construction.</h4>
    		<div class="row">
    			<a href="download.php?currFile=<?php echo $fileName; ?>" class="btn btn-primary col-md-offset-1">Download Data</a>
    		</div>
    		<div class="table-responsive">
    		<table class="table-striped">
    			<tr>
    				<?php foreach($headerArray as $heading){ ?>
    					<td class="col-md-1 text-center"><?php echo $heading; ?></td>
    				<?php } ?>
    			</tr>
    			<?php while($tempAnimal = current($traitArray)){ ?>
    			<tr>
    				<td class="col-md-1 text-center"><?php echo key($traitArray); ?></td>
    				<?php foreach($tempAnimal as $value){ ?>
    					<td class="col-md-1 text-center"><?php echo $value; ?></td>
    				<?php } ?>
    			</tr>
    			<?php next($traitArray); } ?>
    		</table>
    		</div>
    	</div>
    	<?php } ?>
	</div>
</div>
<?php include('includes/footer.inc.php'); ?>
</body>
</html>
<?php mysql_close($connect); ?>