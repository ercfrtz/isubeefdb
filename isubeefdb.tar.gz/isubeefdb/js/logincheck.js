var nocache = 0;
function phgclogin()
{ 
  var username = encodeURI(document.getElementById('username').value);
  var password = encodeURI(document.getElementById('password').value);

  nocache = Math.random();
  
  http.open('get', 'login_check.php?username='+username+'&password='+password+'&nocache = '+nocache);
  http.onreadystatechange = phgcloginReply;
  http.send(null);
}

function phgcloginReply()
{
  if(http.readyState == 4)
  { 
    var response = http.responseText;
    if(response == 0)
    {
      window.location = 'index.php';
    } 
    else 
    {
      window.location = 'index.php';
    }
  }
}
