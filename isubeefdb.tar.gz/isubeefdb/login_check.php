<?php
session_start();

if(isset($_GET['username']) && isset($_GET['password']))
{
	$connect = mysql_connect('localhost:/data/mysql/mysql.sock', "eric", "R1ftw4lker");
	mysql_select_db("isubeefdb");
	$username = $_GET['username'];
	$password = $_GET['password'];
  
  	$sql = "SELECT * from Users WHERE UserName = '$username' and Password = '$password'";
	$query = mysql_query($sql, $connect) or die(mysql_error());
	$result = mysql_fetch_assoc($query);
  	$count = mysql_num_rows($query);
	
	if($count < 1)
  	{
    	echo '0';
  	}
  	else
  	{
    	$_SESSION['authenticated'] = $username;
    	$currentDate = date(Y)."-".date(m)."-".date(d);
    	$sql2 = "select TotalLogins from Users WHERE UserName = '$username'";
    	$query2 = mysql_query($sql2, $connect) or die (mysql_error());
    	$result2 = mysql_fetch_assoc($query2);
    	$totalcount = $result2['TotalLogins'];
    	$totalcount++;
    
    	$sqlSubmit = "update Users set RecentLogin = '$currentDate', TotalLogins = '$totalcount' where UserName = '$username'";
    	$querySubmit = mysql_query($sqlSubmit, $connect) or die (mysql_error());
    
    	echo $username;
  	}
}
?>